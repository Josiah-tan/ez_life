
#================================================================
#
#   File name   : jt_misc.__init__.py
#   Author      : Josiah Tan
#   Created date: 28/11/2020
#   Description : module for miscalleneous stuff
#
#================================================================

#================================================================

from .param2attr import Param2attr
from .jt_property import JTProperty
